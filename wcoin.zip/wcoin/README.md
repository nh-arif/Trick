# wcoin
##### a tool that helps to get unlimited amount of wcoin airdrop
#### use Termux or Terminal  

##### `git clone https://github.com/mosibur1/wcoin.git`
##### `cd wcoin`
##### `pip install -r requirements.txt`
##### `python3 wcoin.py`

##### Drop star if you liked it
#### our telegram Channel @mrptechofficial


















